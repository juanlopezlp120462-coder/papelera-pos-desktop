import sys


from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer


from ui.keyboard import KeyboardAndNumberFilter
from ui.db import init_db
from ui.dashboard import Dashboard


from webhook_server import start_webhook_server
from sync import sincronizar



if __name__ == '__main__':


    app = QApplication(sys.argv)
    from PySide6.QtGui import QGuiApplication


    screen = QGuiApplication.primaryScreen().availableGeometry()

    factor = min(
        screen.width() / 1920,
        screen.height() / 1080
    )

    app.setStyleSheet(f"""
    QWidget {{
        font-size: {int(14 * factor)}px;
    }}
    """)    


    app.setStyleSheet('''

    QMessageBox{
        background:#ffffff;
    }


    QMessageBox QLabel{
        color:#0f172a;
        font-size:14px;
    }


    QMessageBox QPushButton{
        background:#0ea5e9;
        color:white;
        border:0;
        border-radius:8px;
        padding:8px 18px;
        font-weight:700;
    }


    QDialog{
        background:#ffffff;
    }

    ''')



    # ==================================
    # CREAR BASE LOCAL SI NO EXISTE
    # ==================================

    init_db()



    # ==================================
    # SERVIDOR LOCAL DEL POS
    # ==================================

    start_webhook_server()



    # ==================================
    # SINCRONIZACION INICIAL
    # PRODUCTOS + VENTAS
    # ==================================

    try:


        sincronizar()


        print(
            "Sincronización inicial OK"
        )


    except Exception as e:


        print(
            "Error sincronización inicial:",
            e
        )



    # ==================================
    # SINCRONIZACION AUTOMATICA
    # CADA 5 MINUTOS
    # ==================================

    timer_sync = QTimer()


    timer_sync.timeout.connect(
        sincronizar
    )


    timer_sync.start(
        60000
    )



    # ==================================
    # TECLADO ESPECIAL POS
    # ==================================

    keyboard_filter = KeyboardAndNumberFilter(app)


    app.installEventFilter(
        keyboard_filter
    )



    # ==================================
    # PANTALLA PRINCIPAL
    # ==================================

    w = Dashboard()


    w.showMaximized()



    sys.exit(
        app.exec()
    )